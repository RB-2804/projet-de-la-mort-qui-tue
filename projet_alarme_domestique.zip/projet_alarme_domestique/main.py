from flask import Flask, render_template, request, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
from database import init_db, select_sql, insert_sql

app = Flask(__name__)


@app.before_request
def setup_db():
    """
    Initialise la base et crée un compte de test 'demo'
    seulement s'il n'existe pas déjà
    """
    init_db()

    rows = select_sql("SELECT COUNT(*) FROM users WHERE username = ?", ("demo",))
    nb_demo = rows[0][0]

    if nb_demo == 0:
        mdp_hache = generate_password_hash("1234")  # mot de passe haché
        insert_sql("INSERT INTO users (username, password_hash, email) VALUES (?, ?, ?)", ("demo", mdp_hache, "demo@example.com"))


@app.route("/", methods=["GET", "POST"])
def login():
    """
    Page de connexion :
    - Si identifiants corrects -> redirection vers /index
    - Sinon -> message "Nom d'utilisateur ou mot de passe incorrecte"
    """
    message = None
    erreur = None

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()

        if not username or not password:
            erreur = "Merci de remplir les deux champs."
        else:
            # Chercher l'utilisateur dans la base
            rows = select_sql("SELECT id, password_hash FROM users WHERE username = ?", (username,))

            if not rows:
                # Utilisateur non trouvé
                erreur = "Nom d'utilisateur ou mot de passe incorrecte."
            else:
                user_id, mdp_stocke = rows[0]

                # Vérification du mot de passe haché
                if check_password_hash(mdp_stocke, password):
                    return redirect(url_for("home"))
                else:
                    erreur = "Nom d'utilisateur ou mot de passe incorrecte."

    return render_template("login.html", message=message, erreur=erreur)


@app.route("/register", methods=["GET", "POST"])
def register():
    """
    Page de création de compte :
    - username
    - mot de passe haché
    - email
    """
    erreur = None
    message = None

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password1 = request.form.get("password1", "").strip()
        password2 = request.form.get("password2", "").strip()
        email = request.form.get("email", "").strip()

        # Vérifications simples
        if not username or not password1 or not password2 or not email:
            erreur = "Merci de remplir tous les champs."
        elif password1 != password2:
            erreur = "Les deux mots de passe ne correspondent pas."
        else:
            # Vérifier si le nom d'utilisateur existe déjà
            user_existant = select_sql("SELECT id FROM users WHERE username = ?", (username,))

            if user_existant:
                erreur = "Ce nom d'utilisateur existe déjà. Choisis-en un autre."
            else:
                #  Hasher le mot de passe avant de le stocker
                mdp_hache = generate_password_hash(password1)
                insert_sql("INSERT INTO users (username, password_hash, email) VALUES (?, ?, ?)", (username, mdp_hache, email))
                message = "Compte créé avec succès. Tu peux maintenant te connecter."

    return render_template("register.html", erreur=erreur, message=message)


@app.route("/index")
def home():
    """
    Page d'accueil après connexion
    """
    return render_template("index.html")


if __name__ == "__main__":
    app.run(debug=True)
